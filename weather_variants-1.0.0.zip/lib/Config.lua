-- CONFIGURATION: loading this mod's own config.lua.
--
-- This mod has exactly one tunable block -- rarity/encounter chances for
-- weather-variant Pokémon -- so it gets a small, self-contained loader
-- rather than pulling in Weather FX's much larger per-map/force/visual
-- config machinery. Same shape, same guarantees, one block:
--
--   * a missing file is the normal fresh-install case, not an error
--   * a file that fails to compile, fails to run, or does not return a
--     table costs its own contents and nothing else
--   * every number is range-clamped and every unknown key is reported by
--     name through mod.log, never silently dropped
--
-- Weather FX itself is not consulted here: this mod owns its own rarity
-- tuning independently of the host's config file.

local V = ...
local mod = V.mod

local DEFAULTS = {
  -- Persistent weather-variant species offered only by matching live
  -- weather. The ordinary encounter is rolled first through Weather FX's
  -- own tables and remains the result unless this small substitution
  -- chance succeeds.
  weatherVariants = {
    enabled = true,
    encounterChance = 0.03,
    commonChance = 0.05,
    rareChance = 0.03,
    veryRareChance = 0.01,
    legendaryChance = 0.001,
  },
}

local RANGES = {
  ["weatherVariants.encounterChance"] = { 0, 1 },
  ["weatherVariants.commonChance"] = { 0, 1 },
  ["weatherVariants.rareChance"] = { 0, 1 },
  ["weatherVariants.veryRareChance"] = { 0, 1 },
  ["weatherVariants.legendaryChance"] = { 0, 1 },
}

local Config = { FILE = "config.lua", data = nil, problems = {}, found = false }

local function problem(fmt, ...)
  local line = select("#", ...) > 0 and fmt:format(...) or fmt
  Config.problems[#Config.problems + 1] = line
  pcall(function() mod.log:warn("config.lua: %s", line) end)
end

local function deepCopy(t)
  if type(t) ~= "table" then return t end
  local out = {}
  for k, v in pairs(t) do out[k] = deepCopy(v) end
  return out
end

local function clampPath(path, value)
  local range = RANGES[path]
  if not range or type(value) ~= "number" or value ~= value then return value end
  if value < range[1] then
    problem("%s = %s is below %s; clamped", path, tostring(value), tostring(range[1]))
    return range[1]
  end
  if value > range[2] then
    problem("%s = %s is above %s; clamped", path, tostring(value), tostring(range[2]))
    return range[2]
  end
  return value
end

-- Merge `user` over `base` in place, type-checking against `base`. Only
-- one level deep (weatherVariants.*), which is all this file has.
local function merge(base, user, path)
  if type(user) ~= "table" then
    problem("%s should be a table; ignored", path ~= "" and path or "config")
    return base
  end
  for key, value in pairs(user) do
    local sub = (path == "" and tostring(key)) or (path .. "." .. tostring(key))
    local default = base[key]
    if default == nil then
      problem("unknown key %s; ignored", sub)
    elseif type(default) == "table" and type(value) == "table" then
      merge(default, value, sub)
    elseif type(default) == "table" and type(value) ~= "table" then
      problem("%s should be a table; ignored", sub)
    elseif type(value) ~= type(default) then
      problem("%s should be a %s, got %s; ignored", sub, type(default), type(value))
    else
      base[key] = clampPath(sub, value)
    end
  end
  return base
end

function Config.load()
  Config.problems = {}
  local data = deepCopy(DEFAULTS)

  local source = nil
  local okRead = pcall(function() source = mod:read(Config.FILE) end)
  Config.found = (okRead and source ~= nil) and true or false
  if not okRead or not source then
    Config.data = data
    return data
  end

  local loadChunk = loadstring or load
  local chunk, err = loadChunk(source, "@" .. Config.FILE)
  if not chunk then
    problem("did not compile (%s); using defaults", tostring(err))
    Config.data = data
    return data
  end

  local okRun, user = pcall(chunk)
  if not okRun or type(user) ~= "table" then
    problem("did not return a table (%s); using defaults",
      tostring(okRun and type(user) or user))
    Config.data = data
    return data
  end

  merge(data, user, "")
  Config.data = data
  return data
end

function Config.get()
  if not Config.data then Config.load() end
  return Config.data
end

return Config
