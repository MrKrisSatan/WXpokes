-- This mod's own settings page: one row. It used to be a row on Weather
-- FX's page (key "weatherVariants", label "WX POKEMON"); it now lives on
-- this mod's own page instead, for the same reason the species data moved
-- out of Weather FX -- a player who wants only weather can uninstall this
-- mod and lose nothing but the row.
--
-- Species stay registered even when this is OFF. Existing caught variants
-- and their Pokédex/save records therefore remain valid; only new wild
-- substitutions stop. Unregistering live species would corrupt parties and
-- saves made while the option was ON.

local V = ...
local mod = V.mod

local Settings = { _defined = false }

local ROW = {
  key = "weatherVariants", label = "WX POKEMON", type = "choice",
  default = "on",
  choices = { { "ON", "on" }, { "OFF", "off" } },
  help = "Weather-form Pokémon in wild encounters. OFF keeps all Weather FX "
      .. "visuals active but stops new weather variants from appearing. "
      .. "Variants already caught remain usable.",
}

function Settings.define()
  if not mod or not mod.options or type(mod.options.define) ~= "function" then
    pcall(function() mod.log:warn("settings define skipped: mod.options unavailable") end)
    return nil
  end
  local ok, result = pcall(function()
    return mod.options:define({ {
      key = ROW.key, label = ROW.label, type = ROW.type,
      default = ROW.default, choices = ROW.choices, help = ROW.help,
    } })
  end)
  if not ok then
    pcall(function() mod.log:warn("settings define failed: %s", tostring(result)) end)
    return nil
  end
  Settings._defined = true

  -- When the player flips this row, tell Weather FX's encounter code
  -- immediately (no reload) so ON/OFF applies on the next wild roll.
  pcall(function()
    if not mod.options or Settings._optionsSetWrapped then return end
    local rawSet = mod.options.set
    if type(rawSet) ~= "function" then return end
    mod.options.set = function(self, key, value, ...)
      local ret = rawSet(self, key, value, ...)
      if key == "weatherVariants" or tostring(key) == "weatherVariants" then
        pcall(function()
          if not (mod.find) then return end
          local hok, host = pcall(mod.find, "weather_fx")
          if hok and host and host.exports and host.exports.lib then
            local eok, Enc = pcall(host.exports.lib.require, "Encounters")
            if eok and Enc and Enc.syncVariantGate then Enc.syncVariantGate() end
          end
        end)
      end
      return ret
    end
    Settings._optionsSetWrapped = true
  end)
  return result
end

function Settings.weatherVariantsOn()
  local raw
  pcall(function() raw = mod.options:get(ROW.key) end)
  if raw ~= nil then
    if type(raw) == "boolean" then return raw end
    if type(raw) == "number" then
      -- Some hosts store choice index (0/1 or 1/2). Treat 0 and 2 as off.
      if raw == 0 or raw == 2 then return false end
      if raw == 1 then return true end
    end
    local s = tostring(raw):lower():gsub("%s+", "")
    if s == "off" or s == "false" or s == "0" or s == "no" then return false end
    if s == "on" or s == "true" or s == "1" or s == "yes" then return true end
  end
  return ROW.default == "on"
end

return Settings
