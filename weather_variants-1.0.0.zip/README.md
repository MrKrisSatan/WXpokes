# Weather Variants

[#weather-variants](#weather-variants)

Weather-form Pokémon for [Weather FX](https://github.com/MrKrisSatan/Weather-fx).
300 persistent species that can turn up in the wild in place of their base
form, only while the weather they need is actually happening.

This mod does not draw any weather itself and changes nothing about how
Weather FX looks or behaves. It requires Weather FX to be installed, and does
nothing on its own.

---

## Install

[#install](#install)

Drop the `weather_variants` folder into your `mods/` folder, or import the
`.modpkg` through the launcher, alongside Weather FX. Both mods can be
installed and updated independently: uninstalling this one leaves Weather FX
exactly as it was before this mod existed, and updating Weather FX does not
require updating this mod (or vice versa) unless a changelog says otherwise.

Then open this mod's own page in the mod manager and check **WX POKEMON** is
`ON` (it is, by default).

---

## What you get

[#what-you-get](#what-you-get)

**300 core weather variants**, one to three per base species across the
original 151 plus a second full pass on 1–150, each with its own name,
typing and a small chance to replace a normal wild encounter once its
weather is live. Rain-form Bulbasaur ("Bloom"), Ashfall-form Charmander
("Cinder"), Blizzard-form Gyarados, and so on -- see
[`docs/WEATHER_VARIANTS.md`](docs/WEATHER_VARIANTS.md) for the full table.

**470 more when [Kanto-Reforged](https://github.com/) is installed** -- two
weather variants for every species Reforged adds, Chikorita through Deoxys.

**240 more when Gen9Dex (`g9-battle-engine`) is installed** -- two weather
variants each for a curated 120-species modern roster. See
[`docs/GEN9_WEATHER_VARIANTS.md`](docs/GEN9_WEATHER_VARIANTS.md).

**Clean Pokédex integration.** With
[`gen1recomp-national-dex`](https://github.com/sanjinpepic/gen1recomp-national-dex)
installed, every variant registers as a *form* of its base species (synthetic
dex numbers 30000+, invisible on the main list) instead of a new numbered
entry -- variants show up only when you open the base species and cycle
forms, exactly like megas or regional forms.

**A caught variant is permanent.** Turning WX POKEMON off stops *new* wild
substitutions; anything already caught, and its Pokédex/save record, stays
exactly as it was.

---

## Settings

[#settings](#settings)

One row, on this mod's own page in the mod manager:

| Row             | What it does                                                    |
| --------------- | ----------------------------------------------------------------- |
| **WX POKEMON**  | ON/OFF. Changes take effect on the next wild encounter, no reload. |

Rarity tuning (per-rarity substitution chance) lives in this mod's own
`config.lua`, documented inline. It is separate from Weather FX's
`config.lua` -- editing one never touches the other.

---

## How it talks to Weather FX

[#how-it-talks-to-weather-fx](#how-it-talks-to-weather-fx)

Weather FX publishes its whole module namespace as `exports.lib`; this mod's
own `lib/` modules `V.require` each other exactly like Weather FX's do, and a
name not shipped in this mod's own `lib/` folder falls through to Weather
FX's `exports.lib.require` automatically. Weather FX's own encounter code
reaches back into this mod the same way, resolved lazily and fenced with
`pcall` at every step, so this mod being outdated, mid-update, or removed
mid-session never costs more than "no weather variants this encounter" --
never the weather itself, never the game.

Weather FX's public exports (`weatherEncounters`, `weatherPokemon`,
`weatherEncounterAPI`) still exist and still forward to this mod, so a
companion overlay such as Kanto Companion Mobile that used to call
Weather FX directly for variant data keeps working unchanged.

---

## Something not working?

[#something-not-working](#something-not-working)

**No weather variants ever appear.** Check this mod's own **WX POKEMON** row
is `ON`, and that Weather FX's own **WEATHER** row is not `OFF` -- no active
weather means no variant can qualify.

**A variant I expect from Kanto-Reforged or Gen9Dex never shows up.** Those
rosters only load when the relevant mod is detected at boot. Check Weather
FX's `DEBUG HUD` for load order issues, and confirm the other mod's own
folder is present and enabled.

**A caught variant lost its nickname/moves after an update.** That would be a
save-compatibility bug in this mod, not Weather FX -- please report it with
the variant's species id (`WX_###_...`).

## About

Weather-form Pokémon for Weather FX

### Credits

Weather-form roster, typing and Pokédex text: MrKrisSatan.
