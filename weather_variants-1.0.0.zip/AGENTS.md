# AGENTS

Guidance for automated assistants working on **Weather Variants**.
Humans: see README.md. Assistants: read this before editing.

This mod is the weather-form Pokémon roster split out of Weather FX
4.30.77. It owns species data, Pokédex text and the WX POKEMON setting.
It owns no rendering, no draw path, no voxel host code -- for anything
about how weather looks or is composited, that is Weather FX's AGENTS.md,
not this one.

## 1. How this mod reaches Weather FX (and vice versa)

`main.lua`'s `V.require(name)` checks this mod's own `lib/` first and
falls through to `mod.find("weather_fx").exports.lib.require(name)` for
anything not shipped here (`Scene`, `WeatherState`, `Encounters`). Going
the other direction, Weather FX's `lib/Encounters.lua` resolves this mod
through `mod.find("weather_variants")`, fenced with `pcall` at every step
and stubbed to "no variants" when absent.

**Every cross-mod call must degrade to "no weather variants," never to an
error.** A failure here must cost this mod's own feature, not the weather
and not the game. If you add a new touchpoint on either side, fence it
the same way the existing ones are (see `wxOn`/`wxVariants`/`wxConfig` in
Weather FX's `Encounters.lua`, or `host()` in this mod's `main.lua`).

## 2. Run the tests

```bash
cd weather_variants
lua5.1 tests/weather_variants_test.lua     # standalone, fully self-mocked
python3 tools/test_weather_variants.py     # static data contracts + the above
```

Both are self-contained: `weather_variants_test.lua` builds its own fake
`V`/`mod`/`Config`/`Settings`/`Scene` rather than touching Weather FX at
all, so it runs the same whether or not Weather FX is present on disk.

**Known pre-existing failure, not introduced by the mod split:**
`variant record contains only schema-safe inherited fields` fails against
the 4.30.77 source this mod was split from (confirmed against the
untouched upload before any refactor). `WeatherVariantDex`/`install()`'s
clone is leaking `displayName`/`weatherVariant` into the persisted species
record. Real bug, not a test problem -- but it is pre-existing and outside
the scope of any change that doesn't touch `install()`'s clone logic. Fix
it deliberately, not as a drive-by.

## 3. House style (inherited from Weather FX)

- Comments explain **why**. There is a lot of hard-won reasoning in
  `lib/WeatherVariants.lua` (idempotent registration, the CRYSTAL_251
  refusal, the Gen9Dex/national_dex detection order) -- do not strip it.
- Every rarity/chance number is configurable in `config.lua`, not
  hardcoded. Do not quietly change substitution odds.
- Species IDs are `WX_<n>_<BASE>_<VARIANT>`. The numeric prefix is a
  stable sort key, not a Pokédex number -- do not reuse or renumber an
  existing id; it is what a save file's caught-species record points to.
- New rosters (a new generation, a new supplemental pack) follow the same
  shape as `KantoWeatherVariantsData.lua`/`Gen9WeatherVariantsData.lua`:
  their own data file, their own `tools/generate_*.py`, gated on
  detecting the mod they extend, loaded additively into `Variants.data`.
