-- =====================================================================
-- WEATHER VARIANTS -- CONFIGURATION
-- =====================================================================
--
-- Edit this file and restart the game (or press F5 in developer mode).
-- Everything here is optional: delete a key, or the whole file, and the
-- built-in default is used instead. A syntax error here costs you the
-- config, not the mod -- the file is loaded in a sandbox, and a failure
-- is logged and then ignored.
--
-- This is a much smaller file than Weather FX's own config.lua because
-- this mod has exactly one thing to tune: how often a weather variant
-- substitutes for its base species once its weather is active and the
-- WX POKEMON row (in this mod's own page in the mod manager) is ON.
--
-- =====================================================================

return {

  weatherVariants = {
    enabled = true,

    -- Fallback chance used when a variant row has no chance of its own
    -- and no rarity-specific chance below applies.
    encounterChance = 0.03,

    -- Per-rarity substitution chance, 0..1. A variant's own `rarity`
    -- field (common / rare / veryRare / legendary) selects which of
    -- these applies; a row with an explicit `chance` in its data
    -- ignores all of them.
    commonChance    = 0.05,
    rareChance      = 0.03,
    veryRareChance  = 0.01,
    legendaryChance = 0.001,
  },

}
