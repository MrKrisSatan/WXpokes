# Weather Variants 1.0.0

First release as a standalone mod. Split out of Weather FX 4.30.77 (WX
POKEMON) into its own dependent mod, with no gameplay change from that
version's feature:

- 300 core weather-variant species, 470 more with Kanto-Reforged, 240 more
  with Gen9Dex -- unchanged rosters, typing, Pokédex text and abilities.
- Its own settings page (one row: WX POKEMON) and its own `config.lua`
  (rarity/encounter-chance tuning), both moved out of Weather FX's.
- Talks to Weather FX through `exports.lib`, the same interop shape
  Dramatic Shape and other host mods in this ecosystem use -- see this
  mod's README for how the two stay in sync without either one hardcoding
  paths into the other.
- Weather FX's public exports (`weatherEncounters`, `weatherPokemon`,
  `weatherEncounterAPI`) now forward to this mod when it is installed, so
  Kanto Companion Mobile and any other existing consumer needs no changes.

See Weather FX's own `CHANGELOG.md` for this feature's history prior to
the split (first added in Weather FX 4.10, cross-generation dex bridge in
4.27.1, ability assignment and Gen9Dex support in 4.27+).
