# Gen 9 Weather Variants (first batch)

Generated 240 variants for 120 species.
Loaded only when Gen9Dex / g9-battle-engine is installed.

| # | Base | Variant | Types | Weather | Ability |
|---:|---|---|---|---|---|
| 1001 | Sprigatito | BLOOM | GRASS/FAIRY | Rain | CHLOROPHYLL |
| 1002 | Sprigatito | WINTERBLOOM | GRASS/ICE | Snow | SNOW_CLOAK |
| 1003 | Floragato | BLOOM | GRASS/FAIRY | Rain | CHLOROPHYLL |
| 1004 | Floragato | WINTERBLOOM | GRASS/ICE | Snow | SNOW_CLOAK |
| 1005 | Meowscarada | BLOOM | GRASS/DARK | Rain | CHLOROPHYLL |
| 1006 | Meowscarada | WINTERBLOOM | GRASS/DARK | Snow | SNOW_CLOAK |
| 1007 | Fuecoco | CINDER | FIRE/GHOST | Ashfall | FLASH_FIRE |
| 1008 | Fuecoco | RAINSTORM | FIRE/WATER | Storm | DRIZZLE |
| 1009 | Crocalor | CINDER | FIRE/GHOST | Ashfall | FLASH_FIRE |
| 1010 | Crocalor | RAINSTORM | FIRE/WATER | Storm | DRIZZLE |
| 1011 | Skeledirge | CINDER | FIRE/GHOST | Ashfall | FLASH_FIRE |
| 1012 | Skeledirge | RAINSTORM | FIRE/GHOST | Storm | DRIZZLE |
| 1013 | Quaxly | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1014 | Quaxly | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1015 | Quaxwell | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1016 | Quaxwell | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1017 | Quaquaval | TIDAL | WATER/FIGHTING | Hail | ICE_BODY |
| 1018 | Quaquaval | SUNFLARE | WATER/FIGHTING | Heatwave | DROUGHT |
| 1019 | Lechonk | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1020 | Lechonk | TEMPEST | NORMAL/ELECTRIC | Thunderstorm | STATIC |
| 1021 | Oinkologne | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1022 | Oinkologne | TEMPEST | NORMAL/ELECTRIC | Thunderstorm | STATIC |
| 1023 | Tarountula | DEW | BUG/WATER | Rain | SWIFT_SWIM |
| 1024 | Tarountula | TEMPEST | BUG/ELECTRIC | Thunderstorm | STATIC |
| 1025 | Spidops | DEW | BUG/WATER | Rain | SWIFT_SWIM |
| 1026 | Spidops | TEMPEST | BUG/ELECTRIC | Thunderstorm | STATIC |
| 1027 | Nymble | DEW | BUG/WATER | Rain | SWIFT_SWIM |
| 1028 | Nymble | TEMPEST | BUG/ELECTRIC | Thunderstorm | STATIC |
| 1029 | Lokix | NIGHTFOG | BUG/DARK | Moonlit Fog | PRESSURE |
| 1030 | Lokix | CINDERGEIST | BUG/DARK | Ashfall | FLASH_FIRE |
| 1031 | Pawmi | FROSTSPARK | ELECTRIC/ICE | Snow | STATIC |
| 1032 | Pawmi | TEMPEST | ELECTRIC/FLYING | Thunderstorm | LIGHTNING_ROD |
| 1033 | Pawmo | FROSTSPARK | ELECTRIC/FIGHTING | Snow | STATIC |
| 1034 | Pawmo | TEMPEST | ELECTRIC/FIGHTING | Thunderstorm | LIGHTNING_ROD |
| 1035 | Pawmot | FROSTSPARK | ELECTRIC/FIGHTING | Snow | STATIC |
| 1036 | Pawmot | TEMPEST | ELECTRIC/FIGHTING | Thunderstorm | LIGHTNING_ROD |
| 1037 | Tandemaus | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1038 | Tandemaus | TEMPEST | NORMAL/ELECTRIC | Thunderstorm | STATIC |
| 1039 | Maushold | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1040 | Maushold | TEMPEST | NORMAL/ELECTRIC | Thunderstorm | STATIC |
| 1041 | Fidough | MOONLIT | FAIRY/DARK | Moonlit Fog | MAGIC_BOUNCE |
| 1042 | Fidough | TEMPEST | FAIRY/ELECTRIC | Thunderstorm | STATIC |
| 1043 | Dachsbun | MOONLIT | FAIRY/DARK | Moonlit Fog | MAGIC_BOUNCE |
| 1044 | Dachsbun | TEMPEST | FAIRY/ELECTRIC | Thunderstorm | STATIC |
| 1045 | Smoliv | BLOOM | GRASS/NORMAL | Rain | CHLOROPHYLL |
| 1046 | Smoliv | WINTERBLOOM | GRASS/NORMAL | Snow | SNOW_CLOAK |
| 1047 | Dolliv | BLOOM | GRASS/NORMAL | Rain | CHLOROPHYLL |
| 1048 | Dolliv | WINTERBLOOM | GRASS/NORMAL | Snow | SNOW_CLOAK |
| 1049 | Arboliva | BLOOM | GRASS/NORMAL | Rain | CHLOROPHYLL |
| 1050 | Arboliva | WINTERBLOOM | GRASS/NORMAL | Snow | SNOW_CLOAK |
| 1051 | Squawkabilly | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1052 | Squawkabilly | TEMPEST | NORMAL/FLYING | Thunderstorm | STATIC |
| 1053 | Nacli | DUNE | ROCK/GROUND | Sandstorm | SAND_STREAM |
| 1054 | Nacli | TEMPEST | ROCK/ELECTRIC | Thunderstorm | STATIC |
| 1055 | Naclstack | DUNE | ROCK/GROUND | Sandstorm | SAND_STREAM |
| 1056 | Naclstack | TEMPEST | ROCK/ELECTRIC | Thunderstorm | STATIC |
| 1057 | Garganacl | DUNE | ROCK/GROUND | Sandstorm | SAND_STREAM |
| 1058 | Garganacl | TEMPEST | ROCK/ELECTRIC | Thunderstorm | STATIC |
| 1059 | Charcadet | CINDER | FIRE/GHOST | Ashfall | FLASH_FIRE |
| 1060 | Charcadet | RAINSTORM | FIRE/WATER | Storm | DRIZZLE |
| 1061 | Armarouge | CINDER | FIRE/PSYCHIC | Ashfall | FLASH_FIRE |
| 1062 | Armarouge | RAINSTORM | FIRE/PSYCHIC | Storm | DRIZZLE |
| 1063 | Ceruledge | CINDER | FIRE/GHOST | Ashfall | FLASH_FIRE |
| 1064 | Ceruledge | RAINSTORM | FIRE/GHOST | Storm | DRIZZLE |
| 1065 | Tadbulb | FROSTSPARK | ELECTRIC/ICE | Snow | STATIC |
| 1066 | Tadbulb | TEMPEST | ELECTRIC/FLYING | Thunderstorm | LIGHTNING_ROD |
| 1067 | Bellibolt | FROSTSPARK | ELECTRIC/ICE | Snow | STATIC |
| 1068 | Bellibolt | TEMPEST | ELECTRIC/FLYING | Thunderstorm | LIGHTNING_ROD |
| 1069 | Wattrel | FROSTSPARK | ELECTRIC/FLYING | Snow | STATIC |
| 1070 | Wattrel | TEMPEST | ELECTRIC/FLYING | Thunderstorm | LIGHTNING_ROD |
| 1071 | Kilowattrel | FROSTSPARK | ELECTRIC/FLYING | Snow | STATIC |
| 1072 | Kilowattrel | TEMPEST | ELECTRIC/FLYING | Thunderstorm | LIGHTNING_ROD |
| 1073 | Maschiff | NIGHTFOG | DARK/GHOST | Moonlit Fog | PRESSURE |
| 1074 | Maschiff | CINDERGEIST | DARK/FIRE | Ashfall | FLASH_FIRE |
| 1075 | Mabosstiff | NIGHTFOG | DARK/GHOST | Moonlit Fog | PRESSURE |
| 1076 | Mabosstiff | CINDERGEIST | DARK/FIRE | Ashfall | FLASH_FIRE |
| 1077 | Shroodle | VENOM | POISON/NORMAL | Fog | POISON_POINT |
| 1078 | Shroodle | TEMPEST | POISON/NORMAL | Thunderstorm | STATIC |
| 1079 | Grafaiai | VENOM | POISON/NORMAL | Fog | POISON_POINT |
| 1080 | Grafaiai | TEMPEST | POISON/NORMAL | Thunderstorm | STATIC |
| 1081 | Bramblin | BLOOM | GRASS/GHOST | Rain | CHLOROPHYLL |
| 1082 | Bramblin | WINTERBLOOM | GRASS/GHOST | Snow | SNOW_CLOAK |
| 1083 | Brambleghast | BLOOM | GRASS/GHOST | Rain | CHLOROPHYLL |
| 1084 | Brambleghast | WINTERBLOOM | GRASS/GHOST | Snow | SNOW_CLOAK |
| 1085 | Toedscool | BLOOM | GROUND/GRASS | Rain | CHLOROPHYLL |
| 1086 | Toedscool | WINTERBLOOM | GROUND/GRASS | Snow | SNOW_CLOAK |
| 1087 | Toedscruel | BLOOM | GROUND/GRASS | Rain | CHLOROPHYLL |
| 1088 | Toedscruel | WINTERBLOOM | GROUND/GRASS | Snow | SNOW_CLOAK |
| 1089 | Klawf | DUNE | ROCK/GROUND | Sandstorm | SAND_STREAM |
| 1090 | Klawf | TEMPEST | ROCK/ELECTRIC | Thunderstorm | STATIC |
| 1091 | Capsakid | BLOOM | GRASS/FAIRY | Rain | CHLOROPHYLL |
| 1092 | Capsakid | WINTERBLOOM | GRASS/ICE | Snow | SNOW_CLOAK |
| 1093 | Scovillain | CINDER | GRASS/FIRE | Ashfall | FLASH_FIRE |
| 1094 | Scovillain | RAINSTORM | GRASS/FIRE | Storm | DRIZZLE |
| 1095 | Rellor | DEW | BUG/WATER | Rain | SWIFT_SWIM |
| 1096 | Rellor | TEMPEST | BUG/ELECTRIC | Thunderstorm | STATIC |
| 1097 | Rabsca | DEW | BUG/PSYCHIC | Rain | SWIFT_SWIM |
| 1098 | Rabsca | TEMPEST | BUG/PSYCHIC | Thunderstorm | STATIC |
| 1099 | Flittle | DREAMFOG | PSYCHIC/GHOST | Moonlit Fog | PRESSURE |
| 1100 | Flittle | TEMPEST | PSYCHIC/ELECTRIC | Thunderstorm | STATIC |
| 1101 | Espathra | DREAMFOG | PSYCHIC/GHOST | Moonlit Fog | PRESSURE |
| 1102 | Espathra | TEMPEST | PSYCHIC/ELECTRIC | Thunderstorm | STATIC |
| 1103 | Tinkatink | DUNE | FAIRY/STEEL | Sandstorm | SAND_STREAM |
| 1104 | Tinkatink | TEMPEST | FAIRY/STEEL | Thunderstorm | STATIC |
| 1105 | Tinkatuff | DUNE | FAIRY/STEEL | Sandstorm | SAND_STREAM |
| 1106 | Tinkatuff | TEMPEST | FAIRY/STEEL | Thunderstorm | STATIC |
| 1107 | Tinkaton | DUNE | FAIRY/STEEL | Sandstorm | SAND_STREAM |
| 1108 | Tinkaton | TEMPEST | FAIRY/STEEL | Thunderstorm | STATIC |
| 1109 | Wiglett | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1110 | Wiglett | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1111 | Wugtrio | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1112 | Wugtrio | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1113 | Bombirdier | NIGHTFOG | FLYING/DARK | Moonlit Fog | PRESSURE |
| 1114 | Bombirdier | CINDERGEIST | FLYING/DARK | Ashfall | FLASH_FIRE |
| 1115 | Finizen | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1116 | Finizen | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1117 | Palafin | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1118 | Palafin | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1119 | Varoom | DUNE | STEEL/POISON | Sandstorm | SAND_STREAM |
| 1120 | Varoom | TEMPEST | STEEL/POISON | Thunderstorm | STATIC |
| 1121 | Revavroom | DUNE | STEEL/POISON | Sandstorm | SAND_STREAM |
| 1122 | Revavroom | TEMPEST | STEEL/POISON | Thunderstorm | STATIC |
| 1123 | Cyclizar | TEMPEST | DRAGON/NORMAL | Storm | SWIFT_SWIM |
| 1124 | Cyclizar | STORMDRAGON | DRAGON/NORMAL | Storm | DRIZZLE |
| 1125 | Orthworm | DUNE | STEEL/GROUND | Sandstorm | SAND_STREAM |
| 1126 | Orthworm | TEMPEST | STEEL/ELECTRIC | Thunderstorm | STATIC |
| 1127 | Glimmet | DUNE | ROCK/POISON | Sandstorm | SAND_STREAM |
| 1128 | Glimmet | TEMPEST | ROCK/POISON | Thunderstorm | STATIC |
| 1129 | Glimmora | DUNE | ROCK/POISON | Sandstorm | SAND_STREAM |
| 1130 | Glimmora | TEMPEST | ROCK/POISON | Thunderstorm | STATIC |
| 1131 | Greavard | NIGHTFOG | GHOST | Moonlit Fog | PRESSURE |
| 1132 | Greavard | CINDERGEIST | GHOST/FIRE | Ashfall | FLASH_FIRE |
| 1133 | Houndstone | NIGHTFOG | GHOST | Moonlit Fog | PRESSURE |
| 1134 | Houndstone | CINDERGEIST | GHOST/FIRE | Ashfall | FLASH_FIRE |
| 1135 | Flamigo | GALE | FLYING/FIGHTING | Wind | WIND_RIDER |
| 1136 | Flamigo | TEMPEST | FLYING/FIGHTING | Thunderstorm | STATIC |
| 1137 | Cetoddle | TIDAL | ICE | Hail | ICE_BODY |
| 1138 | Cetoddle | SUNFLARE | ICE/FIRE | Heatwave | DROUGHT |
| 1139 | Cetitan | TIDAL | ICE | Hail | ICE_BODY |
| 1140 | Cetitan | SUNFLARE | ICE/FIRE | Heatwave | DROUGHT |
| 1141 | Veluza | TIDAL | WATER/PSYCHIC | Hail | ICE_BODY |
| 1142 | Veluza | SUNFLARE | WATER/PSYCHIC | Heatwave | DROUGHT |
| 1143 | Dondozo | TIDAL | WATER/ICE | Hail | ICE_BODY |
| 1144 | Dondozo | SUNFLARE | WATER/FIRE | Heatwave | DROUGHT |
| 1145 | Tatsugiri | TIDAL | DRAGON/WATER | Hail | ICE_BODY |
| 1146 | Tatsugiri | STORMDRAGON | DRAGON/WATER | Storm | DRIZZLE |
| 1147 | Annihilape | NIGHTFOG | FIGHTING/GHOST | Moonlit Fog | PRESSURE |
| 1148 | Annihilape | CINDERGEIST | FIGHTING/GHOST | Ashfall | FLASH_FIRE |
| 1149 | Clodsire | DUNE | POISON/GROUND | Sandstorm | SAND_STREAM |
| 1150 | Clodsire | TEMPEST | POISON/GROUND | Thunderstorm | STATIC |
| 1151 | Farigiraf | DREAMFOG | NORMAL/PSYCHIC | Moonlit Fog | PRESSURE |
| 1152 | Farigiraf | TEMPEST | NORMAL/PSYCHIC | Thunderstorm | STATIC |
| 1153 | Dudunsparce | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1154 | Dudunsparce | TEMPEST | NORMAL/ELECTRIC | Thunderstorm | STATIC |
| 1155 | Kingambit | DUNE | DARK/STEEL | Sandstorm | SAND_STREAM |
| 1156 | Kingambit | CINDERGEIST | DARK/STEEL | Ashfall | FLASH_FIRE |
| 1157 | Great Tusk | DUNE | GROUND/FIGHTING | Sandstorm | SAND_STREAM |
| 1158 | Great Tusk | TEMPEST | GROUND/FIGHTING | Thunderstorm | STATIC |
| 1159 | Scream Tail | MOONLIT | FAIRY/PSYCHIC | Moonlit Fog | MAGIC_BOUNCE |
| 1160 | Scream Tail | TEMPEST | FAIRY/PSYCHIC | Thunderstorm | STATIC |
| 1161 | Brute Bonnet | BLOOM | GRASS/DARK | Rain | CHLOROPHYLL |
| 1162 | Brute Bonnet | WINTERBLOOM | GRASS/DARK | Snow | SNOW_CLOAK |
| 1163 | Flutter Mane | NIGHTFOG | GHOST/FAIRY | Moonlit Fog | PRESSURE |
| 1164 | Flutter Mane | CINDERGEIST | GHOST/FAIRY | Ashfall | FLASH_FIRE |
| 1165 | Slither Wing | DEW | BUG/FIGHTING | Rain | SWIFT_SWIM |
| 1166 | Slither Wing | TEMPEST | BUG/FIGHTING | Thunderstorm | STATIC |
| 1167 | Sandy Shocks | FROSTSPARK | ELECTRIC/GROUND | Snow | STATIC |
| 1168 | Sandy Shocks | TEMPEST | ELECTRIC/GROUND | Thunderstorm | LIGHTNING_ROD |
| 1169 | Iron Treads | DUNE | GROUND/STEEL | Sandstorm | SAND_STREAM |
| 1170 | Iron Treads | TEMPEST | GROUND/STEEL | Thunderstorm | STATIC |
| 1171 | Iron Bundle | TIDAL | ICE/WATER | Hail | ICE_BODY |
| 1172 | Iron Bundle | SUNFLARE | ICE/WATER | Heatwave | DROUGHT |
| 1173 | Iron Hands | FROSTSPARK | FIGHTING/ELECTRIC | Snow | STATIC |
| 1174 | Iron Hands | TEMPEST | FIGHTING/ELECTRIC | Thunderstorm | LIGHTNING_ROD |
| 1175 | Iron Jugulis | NIGHTFOG | DARK/FLYING | Moonlit Fog | PRESSURE |
| 1176 | Iron Jugulis | CINDERGEIST | DARK/FLYING | Ashfall | FLASH_FIRE |
| 1177 | Iron Moth | CINDER | FIRE/POISON | Ashfall | FLASH_FIRE |
| 1178 | Iron Moth | RAINSTORM | FIRE/POISON | Storm | DRIZZLE |
| 1179 | Iron Thorns | FROSTSPARK | ROCK/ELECTRIC | Snow | STATIC |
| 1180 | Iron Thorns | TEMPEST | ROCK/ELECTRIC | Thunderstorm | LIGHTNING_ROD |
| 1181 | Frigibax | TIDAL | DRAGON/ICE | Hail | ICE_BODY |
| 1182 | Frigibax | STORMDRAGON | DRAGON/ICE | Storm | DRIZZLE |
| 1183 | Arctibax | TIDAL | DRAGON/ICE | Hail | ICE_BODY |
| 1184 | Arctibax | STORMDRAGON | DRAGON/ICE | Storm | DRIZZLE |
| 1185 | Baxcalibur | TIDAL | DRAGON/ICE | Hail | ICE_BODY |
| 1186 | Baxcalibur | STORMDRAGON | DRAGON/ICE | Storm | DRIZZLE |
| 1187 | Gimmighoul | NIGHTFOG | GHOST | Moonlit Fog | PRESSURE |
| 1188 | Gimmighoul | CINDERGEIST | GHOST/FIRE | Ashfall | FLASH_FIRE |
| 1189 | Gholdengo | DUNE | STEEL/GHOST | Sandstorm | SAND_STREAM |
| 1190 | Gholdengo | CINDERGEIST | STEEL/GHOST | Ashfall | FLASH_FIRE |
| 1191 | Wo-Chien | BLOOM | DARK/GRASS | Rain | CHLOROPHYLL |
| 1192 | Wo-Chien | WINTERBLOOM | DARK/GRASS | Snow | SNOW_CLOAK |
| 1193 | Chien-Pao | TIDAL | DARK/ICE | Hail | ICE_BODY |
| 1194 | Chien-Pao | SUNFLARE | DARK/ICE | Heatwave | DROUGHT |
| 1195 | Ting-Lu | DUNE | DARK/GROUND | Sandstorm | SAND_STREAM |
| 1196 | Ting-Lu | CINDERGEIST | DARK/GROUND | Ashfall | FLASH_FIRE |
| 1197 | Chi-Yu | CINDER | DARK/FIRE | Ashfall | FLASH_FIRE |
| 1198 | Chi-Yu | RAINSTORM | DARK/FIRE | Storm | DRIZZLE |
| 1199 | Roaring Moon | NIGHTFOG | DRAGON/DARK | Moonlit Fog | PRESSURE |
| 1200 | Roaring Moon | STORMDRAGON | DRAGON/DARK | Storm | DRIZZLE |
| 1201 | Iron Valiant | MOONLIT | FAIRY/FIGHTING | Moonlit Fog | MAGIC_BOUNCE |
| 1202 | Iron Valiant | TEMPEST | FAIRY/FIGHTING | Thunderstorm | STATIC |
| 1203 | Koraidon | TEMPEST | FIGHTING/DRAGON | Storm | SWIFT_SWIM |
| 1204 | Koraidon | STORMDRAGON | FIGHTING/DRAGON | Storm | DRIZZLE |
| 1205 | Miraidon | FROSTSPARK | ELECTRIC/DRAGON | Snow | STATIC |
| 1206 | Miraidon | STORMDRAGON | ELECTRIC/DRAGON | Storm | DRIZZLE |
| 1207 | Walking Wake | TIDAL | WATER/DRAGON | Hail | ICE_BODY |
| 1208 | Walking Wake | STORMDRAGON | WATER/DRAGON | Storm | DRIZZLE |
| 1209 | Iron Leaves | BLOOM | GRASS/PSYCHIC | Rain | CHLOROPHYLL |
| 1210 | Iron Leaves | WINTERBLOOM | GRASS/PSYCHIC | Snow | SNOW_CLOAK |
| 1211 | Dipplin | BLOOM | GRASS/DRAGON | Rain | CHLOROPHYLL |
| 1212 | Dipplin | STORMDRAGON | GRASS/DRAGON | Storm | DRIZZLE |
| 1213 | Poltchageist | BLOOM | GRASS/GHOST | Rain | CHLOROPHYLL |
| 1214 | Poltchageist | WINTERBLOOM | GRASS/GHOST | Snow | SNOW_CLOAK |
| 1215 | Sinistcha | BLOOM | GRASS/GHOST | Rain | CHLOROPHYLL |
| 1216 | Sinistcha | WINTERBLOOM | GRASS/GHOST | Snow | SNOW_CLOAK |
| 1217 | Okidogi | BRAWL | POISON/FIGHTING | Storm | GUTS |
| 1218 | Okidogi | TEMPEST | POISON/FIGHTING | Thunderstorm | STATIC |
| 1219 | Munkidori | DREAMFOG | POISON/PSYCHIC | Moonlit Fog | PRESSURE |
| 1220 | Munkidori | TEMPEST | POISON/PSYCHIC | Thunderstorm | STATIC |
| 1221 | Fezandipiti | MOONLIT | POISON/FAIRY | Moonlit Fog | MAGIC_BOUNCE |
| 1222 | Fezandipiti | TEMPEST | POISON/FAIRY | Thunderstorm | STATIC |
| 1223 | Ogerpon | BLOOM | GRASS/FAIRY | Rain | CHLOROPHYLL |
| 1224 | Ogerpon | WINTERBLOOM | GRASS/ICE | Snow | SNOW_CLOAK |
| 1225 | Archaludon | DUNE | STEEL/DRAGON | Sandstorm | SAND_STREAM |
| 1226 | Archaludon | STORMDRAGON | STEEL/DRAGON | Storm | DRIZZLE |
| 1227 | Hydrapple | BLOOM | GRASS/DRAGON | Rain | CHLOROPHYLL |
| 1228 | Hydrapple | STORMDRAGON | GRASS/DRAGON | Storm | DRIZZLE |
| 1229 | Gouging Fire | CINDER | FIRE/DRAGON | Ashfall | FLASH_FIRE |
| 1230 | Gouging Fire | STORMDRAGON | FIRE/DRAGON | Storm | DRIZZLE |
| 1231 | Raging Bolt | FROSTSPARK | ELECTRIC/DRAGON | Snow | STATIC |
| 1232 | Raging Bolt | STORMDRAGON | ELECTRIC/DRAGON | Storm | DRIZZLE |
| 1233 | Iron Boulder | DUNE | ROCK/PSYCHIC | Sandstorm | SAND_STREAM |
| 1234 | Iron Boulder | TEMPEST | ROCK/PSYCHIC | Thunderstorm | STATIC |
| 1235 | Iron Crown | DUNE | STEEL/PSYCHIC | Sandstorm | SAND_STREAM |
| 1236 | Iron Crown | TEMPEST | STEEL/PSYCHIC | Thunderstorm | STATIC |
| 1237 | Terapagos | GALE | NORMAL/FLYING | Wind | WIND_RIDER |
| 1238 | Terapagos | TEMPEST | NORMAL/ELECTRIC | Thunderstorm | STATIC |
| 1239 | Pecharunt | NIGHTFOG | POISON/GHOST | Moonlit Fog | PRESSURE |
| 1240 | Pecharunt | CINDERGEIST | POISON/GHOST | Ashfall | FLASH_FIRE |
