# Weather Variants

Weather variants are persistent registered species. They can replace a normal wild roll at a low configured chance only when their mapped Weather FX weather is active and the current map/habitat is suitable. Base sprites, cries, stats, moves, and Pokédex text are inherited when original variant artwork/data is not supplied.

The requested weather label is retained below. Runtime aliases to actual Weather FX IDs are documented in the main README.

| # | Base Pokémon | Variant | Type | Required weather |
|---:|---|---|---|---|
| 001 | Bulbasaur | Bloom | Grass/Fairy | Rain |
| 002 | Ivysaur | Bloom | Grass/Fairy | Rain |
| 003 | Venusaur | Ancient Bloom | Grass/Psychic | Heavy Rain |
| 004 | Charmander | Cinder | Fire/Ghost | Ashfall |
| 005 | Charmeleon | Cinder | Fire/Ghost | Ashfall |
| 006 | Charizard | Inferno | Fire/Dragon | Heatwave |
| 007 | Squirtle | Tidal | Water/Ice | Hail |
| 008 | Wartortle | Tidal | Water/Ice | Hail |
| 009 | Blastoise | Maelstrom | Water/Dark | Storm |
| 010 | Caterpie | Dew | Bug/Water | Rain |
| 011 | Metapod | Cocoon | Bug/Grass | Rain |
| 012 | Butterfree | Monsoon | Bug/Flying | Heavy Rain |
| 013 | Weedle | Venom | Bug/Poison | Fog |
| 014 | Kakuna | Venom | Bug/Poison | Fog |
| 015 | Beedrill | Plague | Bug/Dark | Fog |
| 016 | Pidgey | Gale | Flying/Electric | Wind |
| 017 | Pidgeotto | Gale | Flying/Electric | Wind |
| 018 | Pidgeot | Tempest | Flying/Electric | Thunderstorm |
| 019 | Rattata | Burrow | Ground/Dark | Sandstorm |
| 020 | Raticate | Burrow | Ground/Dark | Sandstorm |
| 021 | Spearow | Storm | Flying/Electric | Thunderstorm |
| 022 | Fearow | Storm | Flying/Electric | Thunderstorm |
| 023 | Ekans | Mire | Poison/Water | Rain |
| 024 | Arbok | Mire | Poison/Water | Heavy Rain |
| 025 | Pikachu | Frostspark | Electric/Ice | Snow |
| 026 | Raichu | Frostspark | Electric/Ice | Snow |
| 027 | Sandshrew | Dune | Ground/Fire | Heatwave |
| 028 | Sandslash | Dune | Ground/Fire | Sandstorm |
| 029 | Nidoran♀ | Bloom | Poison/Grass | Spring Rain |
| 030 | Nidorina | Bloom | Poison/Grass | Spring Rain |
| 031 | Nidoqueen | Bloom | Poison/Grass | Spring Rain |
| 032 | Nidoran♂ | Thorn | Poison/Grass | Spring Rain |
| 033 | Nidorino | Thorn | Poison/Grass | Spring Rain |
| 034 | Nidoking | Thorn | Poison/Grass | Spring Rain |
| 035 | Clefairy | Moonlit | Fairy/Dark | Moonlit Fog |
| 036 | Clefable | Moonlit | Fairy/Dark | Moonlit Fog |
| 037 | Vulpix | Ember | Fire/Ice | Snow |
| 038 | Ninetales | Aurora | Fire/Ice | Snow |
| 039 | Jigglypuff | Mist | Fairy/Water | Fog |
| 040 | Wigglytuff | Mist | Fairy/Water | Fog |
| 041 | Zubat | Blind | Poison/Dark | Fog |
| 042 | Golbat | Blind | Poison/Dark | Fog |
| 043 | Oddish | Nightbloom | Grass/Dark | Moonlit Rain |
| 044 | Gloom | Nightbloom | Grass/Dark | Moonlit Rain |
| 045 | Vileplume | Nightbloom | Grass/Dark | Moonlit Rain |
| 046 | Paras | Spore | Bug/Grass | Rain |
| 047 | Parasect | Spore | Bug/Grass | Heavy Rain |
| 048 | Venonat | Mist | Bug/Psychic | Fog |
| 049 | Venomoth | Mist | Bug/Psychic | Fog |
| 050 | Diglett | Buried | Ground/Ghost | Sandstorm |
| 051 | Dugtrio | Buried | Ground/Ghost | Sandstorm |
| 052 | Meowth | Alley | Dark/Electric | Thunderstorm |
| 053 | Persian | Alley | Dark/Electric | Thunderstorm |
| 054 | Psyduck | Rainmind | Water/Psychic | Rain |
| 055 | Golduck | Rainmind | Water/Psychic | Heavy Rain |
| 056 | Mankey | Dust | Fighting/Ground | Dust Storm |
| 057 | Primeape | Dust | Fighting/Ground | Dust Storm |
| 058 | Growlithe | Wildfire | Fire/Dark | Heatwave |
| 059 | Arcanine | Wildfire | Fire/Dragon | Heatwave |
| 060 | Poliwag | Bog | Water/Grass | Rain |
| 061 | Poliwhirl | Bog | Water/Grass | Rain |
| 062 | Poliwrath | Bog | Water/Fighting | Heavy Rain |
| 063 | Abra | Mirage | Psychic/Ghost | Heat Haze |
| 064 | Kadabra | Mirage | Psychic/Ghost | Heat Haze |
| 065 | Alakazam | Mirage | Psychic/Ghost | Heat Haze |
| 066 | Machop | Mountain | Fighting/Rock | Dust Storm |
| 067 | Machoke | Mountain | Fighting/Rock | Dust Storm |
| 068 | Machamp | Mountain | Fighting/Rock | Sandstorm |
| 069 | Bellsprout | Vine | Grass/Poison | Rain |
| 070 | Weepinbell | Vine | Grass/Poison | Heavy Rain |
| 071 | Victreebel | Carnivine | Grass/Dark | Heavy Rain |
| 072 | Tentacool | Brine | Water/Poison | Storm |
| 073 | Tentacruel | Brine | Water/Poison | Storm |
| 074 | Geodude | Mudstone | Rock/Water | Rain |
| 075 | Graveler | Mudstone | Rock/Water | Heavy Rain |
| 076 | Golem | Magmastone | Rock/Fire | Heatwave |
| 077 | Ponyta | Frostfire | Fire/Ice | Snow |
| 078 | Rapidash | Frostfire | Fire/Ice | Snow |
| 079 | Slowpoke | Marsh | Water/Grass | Rain |
| 080 | Slowbro | Marsh | Water/Grass | Rain |
| 081 | Magnemite | Stormcore | Electric/Steel | Thunderstorm |
| 082 | Magneton | Stormcore | Electric/Steel | Thunderstorm |
| 083 | Farfetch'd | Harvest | Flying/Grass | Autumn Rain |
| 084 | Doduo | Dustwing | Normal/Ground | Dust Storm |
| 085 | Dodrio | Dustwing | Ground/Flying | Sandstorm |
| 086 | Seel | Glacier | Water/Ice | Hail |
| 087 | Dewgong | Glacier | Water/Ice | Hail |
| 088 | Grimer | Sludge | Poison/Water | Rain |
| 089 | Muk | Toxic Tide | Poison/Water | Acid Rain |
| 090 | Shellder | Frostshell | Water/Ice | Snow |
| 091 | Cloyster | Frostshell | Water/Ice | Hail |
| 092 | Gastly | Cindergeist | Ghost/Fire | Ashfall |
| 093 | Haunter | Cindergeist | Ghost/Fire | Ashfall |
| 094 | Gengar | Cindergeist | Ghost/Fire | Ashfall |
| 095 | Onix | Thunderstone | Rock/Electric | Thunderstorm |
| 096 | Drowzee | Dreamfog | Psychic/Ghost | Fog |
| 097 | Hypno | Dreamfog | Psychic/Ghost | Fog |
| 098 | Krabby | Mudclaw | Water/Ground | Rain |
| 099 | Kingler | Mudclaw | Water/Ground | Heavy Rain |
| 100 | Voltorb | Stormorb | Electric/Water | Thunderstorm |
| 101 | Electrode | Stormorb | Electric/Water | Thunderstorm |
| 102 | Exeggcute | Sunseed | Grass/Fire | Sunny |
| 103 | Exeggutor | Sunseed | Grass/Fire | Sunny |
| 104 | Cubone | Bonecold | Ground/Ice | Snow |
| 105 | Marowak | Bonecold | Ground/Ice | Snow |
| 106 | Hitmonlee | Dustfighter | Fighting/Ground | Dust Storm |
| 107 | Hitmonchan | Dustfighter | Fighting/Ground | Dust Storm |
| 108 | Lickitung | Swamp | Normal/Water | Rain |
| 109 | Koffing | Smog | Poison/Fire | Smog |
| 110 | Weezing | Smog | Poison/Fire | Smog |
| 111 | Rhyhorn | Mudhorn | Ground/Water | Rain |
| 112 | Rhydon | Mudhorn | Ground/Water | Heavy Rain |
| 113 | Chansey | Spring | Normal/Fairy | Spring Rain |
| 114 | Tangela | Rainvine | Grass/Water | Rain |
| 115 | Kangaskhan | Dustmother | Ground/Normal | Dust Storm |
| 116 | Horsea | Stormsea | Water/Electric | Storm |
| 117 | Seadra | Stormsea | Water/Electric | Storm |
| 118 | Goldeen | Moonfin | Water/Fairy | Moonlit Rain |
| 119 | Seaking | Moonfin | Water/Fairy | Moonlit Rain |
| 120 | Staryu | Starfrost | Water/Ice | Snow |
| 121 | Starmie | Starfrost | Water/Ice | Aurora |
| 122 | Mr. Mime | Mirage | Psychic/Fairy | Heat Haze |
| 123 | Scyther | Windcutter | Bug/Flying | Wind |
| 124 | Jynx | Blizzard | Ice/Psychic | Blizzard |
| 125 | Electabuzz | Thunder | Electric/Fighting | Thunderstorm |
| 126 | Magmar | Volcano | Fire/Rock | Ashfall |
| 127 | Pinsir | Monsoon | Bug/Water | Heavy Rain |
| 128 | Tauros | Stampede | Normal/Ground | Dust Storm |
| 129 | Magikarp | Flood | Water/Ground | Flood |
| 130 | Gyarados | Typhoon | Water/Flying | Typhoon |
| 131 | Lapras | Icebound | Water/Ice | Blizzard |
| 132 | Ditto | Weatherbound | Normal | Any rare weather |
| 133 | Eevee | Seasonal | Normal | Seasonal |
| 134 | Vaporeon | Monsoon | Water/Electric | Heavy Rain |
| 135 | Jolteon | Thunder | Electric/Flying | Thunderstorm |
| 136 | Flareon | Wildfire | Fire/Ground | Heatwave |
| 137 | Porygon | Glitch | Electric/Psychic | Static Storm |
| 138 | Omanyte | Ancient Tide | Rock/Water | Storm |
| 139 | Omastar | Ancient Tide | Rock/Water | Storm |
| 140 | Kabuto | Ancient Sand | Rock/Ground | Sandstorm |
| 141 | Kabutops | Ancient Sand | Rock/Ground | Sandstorm |
| 142 | Aerodactyl | Tempest | Rock/Flying | Wind |
| 143 | Snorlax | Hibernal | Normal/Ice | Snow |
| 144 | Articuno | Aurora | Ice/Flying | Aurora |
| 145 | Zapdos | Tempest | Electric/Flying | Thunderstorm |
| 146 | Moltres | Ashen | Fire/Flying | Ashfall |
| 147 | Dratini | Mistcoil | Dragon/Water | Fog |
| 148 | Dragonair | Mistcoil | Dragon/Water | Fog |
| 149 | Dragonite | Tempest | Dragon/Flying | Storm |
| 150 | Mewtwo | Void | Psychic/Dark | Eclipse |
| 151 | Bulbasaur | Winterbloom | Grass/Ice | Snow |
| 152 | Ivysaur | Winterbloom | Grass/Ice | Snow |
| 153 | Venusaur | Winterbloom | Grass/Ice | Blizzard |
| 154 | Charmander | Sunflare | Fire/Electric | Sunny |
| 155 | Charmeleon | Sunflare | Fire/Electric | Sunny |
| 156 | Charizard | Solarflare | Fire/Electric | Heatwave |
| 157 | Squirtle | Swamp | Water/Grass | Rain |
| 158 | Wartortle | Swamp | Water/Grass | Rain |
| 159 | Blastoise | Monsoon | Water/Electric | Storm |
| 160 | Caterpie | Autumn | Bug/Grass | Autumn Rain |
| 161 | Metapod | Autumn | Bug/Grass | Autumn Rain |
| 162 | Butterfree | Autumn | Bug/Fairy | Autumn Rain |
| 163 | Weedle | Winter | Bug/Ice | Snow |
| 164 | Kakuna | Winter | Bug/Ice | Snow |
| 165 | Beedrill | Winter | Bug/Ice | Blizzard |
| 166 | Pidgey | Frostwing | Ice/Flying | Snow |
| 167 | Pidgeotto | Frostwing | Ice/Flying | Snow |
| 168 | Pidgeot | Frostwing | Ice/Flying | Blizzard |
| 169 | Rattata | Floodrat | Water/Dark | Flood |
| 170 | Raticate | Floodrat | Water/Dark | Flood |
| 171 | Spearow | Ashwing | Fire/Flying | Ashfall |
| 172 | Fearow | Ashwing | Fire/Flying | Ashfall |
| 173 | Ekans | Sandviper | Ground/Poison | Sandstorm |
| 174 | Arbok | Sandviper | Ground/Poison | Sandstorm |
| 175 | Pikachu | Rainbolt | Electric/Water | Rain |
| 176 | Raichu | Rainbolt | Electric/Water | Storm |
| 177 | Sandshrew | Snowshrew | Ice/Ground | Snow |
| 178 | Sandslash | Snowshrew | Ice/Ground | Blizzard |
| 179 | Nidoran♀ | Mire | Poison/Water | Rain |
| 180 | Nidorina | Mire | Poison/Water | Rain |
| 181 | Nidoqueen | Mire | Poison/Water | Heavy Rain |
| 182 | Nidoran♂ | Mire | Poison/Water | Rain |
| 183 | Nidorino | Mire | Poison/Water | Rain |
| 184 | Nidoking | Mire | Poison/Water | Heavy Rain |
| 185 | Clefairy | Frostmoon | Fairy/Ice | Snow |
| 186 | Clefable | Frostmoon | Fairy/Ice | Aurora |
| 187 | Vulpix | Mistflame | Fire/Fairy | Fog |
| 188 | Ninetales | Mistflame | Fire/Fairy | Fog |
| 189 | Jigglypuff | Dream | Fairy/Psychic | Moonlit Fog |
| 190 | Wigglytuff | Dream | Fairy/Psychic | Moonlit Fog |
| 191 | Zubat | Stormbat | Poison/Flying | Thunderstorm |
| 192 | Golbat | Stormbat | Poison/Electric | Thunderstorm |
| 193 | Oddish | Sunroot | Grass/Fire | Sunny |
| 194 | Gloom | Sunroot | Grass/Fire | Sunny |
| 195 | Vileplume | Sunroot | Grass/Fire | Sunny |
| 196 | Paras | Frostspore | Bug/Ice | Snow |
| 197 | Parasect | Frostspore | Bug/Ice | Blizzard |
| 198 | Venonat | Rainveil | Bug/Water | Rain |
| 199 | Venomoth | Rainveil | Bug/Water | Heavy Rain |
| 200 | Diglett | Flooded | Water/Ground | Flood |
| 201 | Dugtrio | Flooded | Water/Ground | Flood |
| 202 | Meowth | Frostclaw | Ice/Dark | Snow |
| 203 | Persian | Frostclaw | Ice/Dark | Blizzard |
| 204 | Psyduck | Sunbrain | Water/Fire | Sunny |
| 205 | Golduck | Sunbrain | Water/Fire | Sunny |
| 206 | Mankey | Stormrage | Fighting/Electric | Thunderstorm |
| 207 | Primeape | Stormrage | Fighting/Electric | Thunderstorm |
| 208 | Growlithe | Rainfire | Fire/Water | Rain |
| 209 | Arcanine | Rainfire | Fire/Water | Heavy Rain |
| 210 | Poliwag | Frostbog | Water/Ice | Snow |
| 211 | Poliwhirl | Frostbog | Water/Ice | Snow |
| 212 | Poliwrath | Frostbog | Water/Ice | Blizzard |
| 213 | Abra | Dream | Psychic/Fairy | Moonlit Fog |
| 214 | Kadabra | Dream | Psychic/Fairy | Moonlit Fog |
| 215 | Alakazam | Dream | Psychic/Fairy | Moonlit Fog |
| 216 | Machop | Rainfighter | Fighting/Water | Rain |
| 217 | Machoke | Rainfighter | Fighting/Water | Rain |
| 218 | Machamp | Rainfighter | Fighting/Water | Storm |
| 219 | Bellsprout | Sunvine | Grass/Fire | Sunny |
| 220 | Weepinbell | Sunvine | Grass/Fire | Sunny |
| 221 | Victreebel | Sunvine | Grass/Fire | Heatwave |
| 222 | Tentacool | Frosttentacle | Water/Ice | Hail |
| 223 | Tentacruel | Frosttentacle | Water/Ice | Hail |
| 224 | Geodude | Sandstone | Rock/Ground | Sandstorm |
| 225 | Graveler | Sandstone | Rock/Ground | Sandstorm |
| 226 | Golem | Sandstone | Rock/Ground | Sandstorm |
| 227 | Ponyta | Ashmane | Fire/Ghost | Ashfall |
| 228 | Rapidash | Ashmane | Fire/Ghost | Ashfall |
| 229 | Slowpoke | Snowpoke | Water/Ice | Snow |
| 230 | Slowbro | Snowpoke | Water/Ice | Blizzard |
| 231 | Magnemite | Static | Electric/Ghost | Static Storm |
| 232 | Magneton | Static | Electric/Ghost | Static Storm |
| 233 | Farfetch'd | Gale | Flying/Grass | Wind |
| 234 | Doduo | Sandrunner | Ground/Flying | Sandstorm |
| 235 | Dodrio | Sandrunner | Ground/Flying | Sandstorm |
| 236 | Seel | Rainseal | Water/Fairy | Rain |
| 237 | Dewgong | Rainseal | Water/Fairy | Heavy Rain |
| 238 | Grimer | Acid | Poison/Water | Acid Rain |
| 239 | Muk | Acid | Poison/Water | Acid Rain |
| 240 | Shellder | Stormshell | Water/Electric | Storm |
| 241 | Cloyster | Stormshell | Water/Electric | Storm |
| 242 | Gastly | Moongeist | Ghost/Fairy | Moonlit Fog |
| 243 | Haunter | Moongeist | Ghost/Fairy | Moonlit Fog |
| 244 | Gengar | Moongeist | Ghost/Fairy | Eclipse |
| 245 | Onix | Froststone | Rock/Ice | Snow |
| 246 | Drowzee | Sunstroke | Psychic/Fire | Heatwave |
| 247 | Hypno | Sunstroke | Psychic/Fire | Heatwave |
| 248 | Krabby | Snowclaw | Water/Ice | Snow |
| 249 | Kingler | Snowclaw | Water/Ice | Hail |
| 250 | Voltorb | Rainorb | Electric/Water | Rain |
| 251 | Electrode | Rainorb | Electric/Water | Storm |
| 252 | Exeggcute | Rainseed | Grass/Water | Rain |
| 253 | Exeggutor | Rainseed | Grass/Water | Heavy Rain |
| 254 | Cubone | Ashbone | Ground/Fire | Ashfall |
| 255 | Marowak | Ashbone | Ground/Fire | Ashfall |
| 256 | Hitmonlee | Heatfighter | Fighting/Fire | Heatwave |
| 257 | Hitmonchan | Heatfighter | Fighting/Fire | Heatwave |
| 258 | Lickitung | Frosttongue | Normal/Ice | Snow |
| 259 | Koffing | Stormsmog | Poison/Electric | Thunderstorm |
| 260 | Weezing | Stormsmog | Poison/Electric | Thunderstorm |
| 261 | Rhyhorn | Sandhorn | Ground/Rock | Sandstorm |
| 262 | Rhydon | Sandhorn | Ground/Rock | Sandstorm |
| 263 | Chansey | Moonblessed | Normal/Fairy | Moonlit Fog |
| 264 | Tangela | Frostvine | Grass/Ice | Snow |
| 265 | Kangaskhan | Rainmother | Normal/Water | Rain |
| 266 | Horsea | Frostsea | Water/Ice | Hail |
| 267 | Seadra | Frostsea | Water/Ice | Hail |
| 268 | Goldeen | Rainfin | Water/Grass | Rain |
| 269 | Seaking | Rainfin | Water/Grass | Heavy Rain |
| 270 | Staryu | Stormstar | Water/Electric | Storm |
| 271 | Starmie | Stormstar | Water/Electric | Storm |
| 272 | Mr. Mime | Fogmime | Psychic/Ghost | Fog |
| 273 | Scyther | Rainblade | Bug/Water | Rain |
| 274 | Jynx | Ashwitch | Ice/Fire | Ashfall |
| 275 | Electabuzz | Staticfist | Electric/Fighting | Static Storm |
| 276 | Magmar | Ashmagmar | Fire/Ghost | Ashfall |
| 277 | Pinsir | Drought | Bug/Ground | Heatwave |
| 278 | Tauros | Thunderbull | Normal/Electric | Thunderstorm |
| 279 | Magikarp | Frostkarp | Water/Ice | Snow |
| 280 | Gyarados | Blizzard | Water/Ice | Blizzard |
| 281 | Lapras | Stormsong | Water/Electric | Storm |
| 282 | Ditto | Prismatic | Normal/Fairy | Aurora |
| 283 | Eevee | Weatherling | Normal | Any seasonal weather |
| 284 | Vaporeon | Frostwave | Water/Ice | Snow |
| 285 | Jolteon | Rainshock | Electric/Water | Rain |
| 286 | Flareon | Ashflare | Fire/Ghost | Ashfall |
| 287 | Porygon | Static | Electric/Steel | Static Storm |
| 288 | Omanyte | Frostfossil | Rock/Ice | Snow |
| 289 | Omastar | Frostfossil | Rock/Ice | Blizzard |
| 290 | Kabuto | Rainfossil | Rock/Water | Rain |
| 291 | Kabutops | Rainfossil | Rock/Water | Heavy Rain |
| 292 | Aerodactyl | Stormwing | Rock/Electric | Thunderstorm |
| 293 | Snorlax | Rainbear | Normal/Water | Rain |
| 294 | Articuno | Stormfrost | Ice/Electric | Blizzard |
| 295 | Zapdos | Rainstorm | Electric/Water | Storm |
| 296 | Moltres | Solarash | Fire/Psychic | Heatwave |
| 297 | Dratini | Snowcoil | Dragon/Ice | Snow |
| 298 | Dragonair | Snowcoil | Dragon/Ice | Blizzard |
| 299 | Dragonite | Stormdragon | Dragon/Electric | Thunderstorm |
| 300 | Mew | Primalweather | Psychic/Fairy | Eclipse |
# Pokédex entries

All 300 weather variants have their own original Pokédex description. Weather FX registers Gen 1 text-table keys and supplies Gen 2 `gen2Pokedex` rows when that data is available. Each variant keeps its base Pokémon's numeric Pokédex number for Kanto Reforged's regional species filters, while its unique `WX_*` species ID keeps seen, owned, and caught state separate.

Kanto Reforged is an optional dependency and remains a separate mod. Install both archives normally; do not combine their folders.

# Kanto Reforged supplemental variants

When Kanto Reforged is detected, Weather FX loads 470 additional variants: two for every added species from Chikorita (#152) through Deoxys (#386). They use the same persistent registered-species, weather-gated encounter, evolution rewrite, rarity, and Pokédex-entry systems as the original 300. Without Kanto Reforged, this supplemental data is not loaded or registered and the catalog remains at 300 variants.

## Abilities (4.27+)

Weather variants now receive more appropriate abilities:

- Explicit `ability = "BEADS_OF_RUIN"` (or any other ability id) on a data row overrides everything.
- Otherwise a thematic ability is chosen from the variant's weather and typing (examples):
  - Primalweather / Eclipse → Beads of Ruin
  - Heavy rain / Storm (Water) → Drizzle or Swift Swim
  - Harsh sun / Heatwave (Fire) → Drought or Chlorophyll
  - Sandstorm / Dust → Sand Stream
  - Snow / Hail / Blizzard → Snow Warning
  - Thunderstorm → Static
  - Fog / Mist → Forecast (or Pressure)
  - Ashfall → Flash Fire
  - Strong winds → Wind Rider
- If the chosen ability is not registered by the engine or another mod (e.g. Gen9Dex), the engine falls back gracefully; the base species ability remains available as a last resort.

Example: **Primalweather Mew** (`WX_300_MEW_PRIMALWEATHER`) is assigned **Beads of Ruin**.

## Gen9Dex compatibility

When the Gen9Dex mod (`g9-battle-engine`) is installed, Weather FX loads an additional cohort of weather variants from `lib/Gen9WeatherVariantsData.lua` (two variants per Gen 9 species when the full roster is generated).

This path is independent of Kanto-Reforged. Players who prefer Gen9Dex over Kanto-Reforged (or vice-versa) still receive weather variants for the species that mod provides. The data file currently ships as a seed; expand it with the generator once national_dex species are available at build time.

## national_dex compatibility (4.27.1)

When [gen1recomp-national-dex](https://github.com/sanjinpepic/gen1recomp-national-dex) is installed, weather variants are registered as **forms** of their base species:

- `baseSpecies` + `form` fields so national_dex's LEFT/RIGHT form browser finds them
- Synthetic dex numbers in the 30000+ range (invisible on the main 1–1025 list)
- `baseDex` preserves the real national number for display

This keeps the Pokédex clean: variants never appear as extra numbered entries, never break sorting, seen-only mode, or page jumps. They appear only when you open the base species and cycle forms.

## Learnsets (4.27.3)

Weather variants adapt their level-up learnsets to the new typing on registration:

1. Offensive moves of a **dropped** type are replaced with thematic moves of an **added** type (early / mid / late tiers).
2. Each new type is guaranteed at least one STAB move on the curve (and in level-1 moves when possible).
3. Status, Normal, and moves that still match a retained type are kept.
4. Only move IDs present in the engine (or a known core set) are written — unavailable modern moves are skipped.

Applies to `learnset`, `level1Moves`, and optional `movesFull` fields.
