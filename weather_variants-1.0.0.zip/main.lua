-- WEATHER VARIANTS -- weather-form Pokémon for Weather FX.
--
-- =====================================================================
-- WHAT THIS IS
-- =====================================================================
--
-- 300 persistent registered species (plus 470 more when Kanto-Reforged is
-- installed, plus 240 more when Gen9Dex is installed) that can replace a
-- normal wild roll at a small configured chance, only while their mapped
-- Weather FX weather is active and the current map/habitat is suitable.
-- Base sprites, cries, stats, moves and Pokédex text are inherited when
-- original variant artwork/data is not supplied.
--
-- This was previously part of Weather FX itself. It is a separate,
-- dependent mod now so a player who wants only weather -- no custom
-- species -- can skip this entirely, and so this mod's own release cycle
-- (new variants, new generations) does not force a Weather FX update.
--
-- =====================================================================
-- HOW IT TALKS TO WEATHER FX
-- =====================================================================
--
-- Weather FX publishes its whole module namespace as `exports.lib`, the
-- same shape Dramatic Shape and other host mods in this ecosystem use.
-- lib/ modules here `V.require` each other exactly like Weather FX's own
-- lib/ does; the one difference is that a name not found in THIS mod's
-- own lib/ folder falls through to Weather FX's `exports.lib.require`
-- instead of erroring, so lib/WeatherVariants.lua and friends can read
-- Weather FX's Scene and WeatherState without knowing they moved.
--
-- Weather FX is a hard dependency (see manifest.json): this mod does not
-- attempt to run without it, and the modkit is expected to load
-- dependencies first. Every cross-mod call is still pcall'd, because a
-- failure here must cost weather variants, never the game or the weather
-- itself.

local mod = ...

local V = { mod = mod, path = mod.path }

local loadChunk = loadstring or load

local function chunkFor(rel)
  local ok, source = pcall(function() return mod:read(rel) end)
  if not ok or not source then return nil end
  local chunk, err = loadChunk(source, "@" .. mod.path .. "/" .. rel)
  if not chunk then
    error(("weather_variants: %s did not compile: %s"):format(rel, tostring(err)), 0)
  end
  return chunk
end

local hostHandle = nil
local function host()
  if hostHandle ~= nil then return hostHandle or nil end
  local found = false
  if mod and mod.find then
    local ok, handle = pcall(mod.find, "weather_fx")
    if ok and handle and handle.exports and handle.exports.lib then
      hostHandle = handle
      found = true
    end
  end
  if not found then hostHandle = false end
  return hostHandle or nil
end

local modules = {}
function V.require(name)
  local hit = modules[name]
  if hit ~= nil then return hit end
  local chunk = chunkFor("lib/" .. name .. ".lua")
  local value
  if chunk then
    value = chunk(V)
  else
    local h = host()
    if not h then
      error(("weather_variants: %s is not shipped by this mod and Weather FX "
        .. "is not installed"):format(name), 0)
    end
    value = h.exports.lib.require(name)
  end
  modules[name] = value
  return value
end

local Config = V.require("Config")
Config.load()          -- first, because WeatherVariants reads it on require

local Settings = V.require("Settings")
do
  local function ensureOptions()
    local ok, err = pcall(Settings.define)
    if not ok then
      pcall(function() mod.log:warn("settings define failed: %s", tostring(err)) end)
    end
  end
  ensureOptions()
  pcall(function()
    if mod.hooks and mod.hooks.on then
      mod.hooks:on("game.ready", ensureOptions)
      mod.hooks:on("game.start", ensureOptions)
      mod.hooks:on("save.loaded", ensureOptions)
    end
  end)
  pcall(function()
    if mod.events and mod.events.on then
      mod.events:on("save.loaded", ensureOptions)
      mod.events:on("save.created", ensureOptions)
    end
  end)
end

-- Register weather-form species before any encounter hook needs them, so
-- Weather FX's Encounters.lua and any read-only consumer (Kanto Companion
-- Mobile, via Weather FX's forwarding exports) can find real merged
-- species records from the very first frame.
--
-- CRYSTAL_251 ships its own type chart and its own 251 dex; overlaying
-- weather variants on top of it was never supported and is refused here,
-- same as it always was inside Weather FX.
local WeatherVariants = V.require("WeatherVariants")
local WeatherEncounterAPI = V.require("WeatherEncounterAPI")

local function crystal251Present()
  local ok, present = pcall(function() return mod.find and mod.find("CRYSTAL_251") end)
  return ok and present and true or false
end

if not crystal251Present() then
  local vok, verr = pcall(WeatherVariants.install)
  if not vok then
    pcall(function() mod.log:warn("weather variants install failed: %s", tostring(verr)) end)
  end
end

mod.events:on("game.ready", function()
  pcall(function()
    if crystal251Present() then return end
    local ok, WV = pcall(function() return WeatherVariants end)
    if ok and WV and WV.install then pcall(WV.install) end
    if ok and WV and WV.bindPokedex then WV.bindPokedex() end
    -- Wilds of Kanto (overworld-spawn-mod): remap WX_* follower sprites to base.
    if ok and WV and WV.installWildsCompat then pcall(WV.installWildsCompat) end
    pcall(WeatherEncounterAPI.bind)
  end)
  pcall(function()
    mod.log:info("weather_variants %s: %d core rows (%s, %s)",
      mod.exports.version, #(WeatherVariants.data or {}),
      WeatherVariants.kantoReforged and "Kanto-Reforged loaded" or "Kanto-Reforged absent",
      WeatherVariants.gen9Dex and "Gen9Dex loaded" or "Gen9Dex absent")
  end)
end)

-- ------- exports
--
-- The same public shape Weather FX used to expose directly, so a
-- companion mod calling weather_fx.exports.weatherEncounters(...) keeps
-- working unchanged whether it talks to Weather FX's forwarding shim or
-- (as new integrations should) straight to this mod.

mod.exports.version = (mod.manifest and mod.manifest.version) or "unknown"
mod.exports.lib = V
mod.exports.weatherVariantsOn = function() return Settings.weatherVariantsOn() end
mod.exports.encounterOverlay = function(mapId) return WeatherEncounterAPI.route(mapId) end
mod.exports.weatherEncounters = function(mapId) return WeatherEncounterAPI.route(mapId) end
mod.exports.weatherPokemon = function(species) return WeatherEncounterAPI.species(species) end
mod.exports.weatherEncounterAPI = WeatherEncounterAPI.public()
